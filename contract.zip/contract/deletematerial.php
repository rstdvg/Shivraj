<?php
require_once '../contract/Lib/config.php';
if(isset($_GET['id'])) {

  $mid = 'm_id';
  $id = $_GET['id'];
  $table = 'addmaterial';

  if ($contract->delete_materialValue($table,$mid,$id)) {
    header("location:viewmaterial.php");
  }
}
?>