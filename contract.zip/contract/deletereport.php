<?php
 require_once '../contract/Lib/config.php';
$id=$_GET['del_rep'];
$table='uploadreport';
$contract->single_report_delete($id,$table);
header('Location:viewreport.php');
?>