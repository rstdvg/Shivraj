
<html>
  <head>
  	<link href="css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.min.js"></script>
    <link rel="stylesheet" type="text/css" href="css/stylelogin.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <style type="text/css">
        .error_msg{
            color:red;
            font-size: 16px;
        }
    </style>
  </head>
<body id="LoginForm">
<div class="container">
<div class="login-form">
<div class="main-div">
	  <?php
require_once '../contract/Lib/config.php';
if(isset($_POST['login']))   // button 
{
$uname=$_POST['username'];
$pwd=$_POST['password'];
$table="login";
if($result=$contract->login($uname,$pwd,$table)){
$username=$result['username'];
$password=$result['password'];
$role=$result['role'];

  if ($username==$uname && $password==$pwd) {
   session_start();
   if($role=="admin")
   {
    $_SESSION['user_name']=$username;
    header("location:dashboard.php");
   }
   elseif($role=="supervisor")
    {
    $_SESSION['user_name']=$username;
    header("location:supervisior.php");
    }
  }
}
else{
    
    echo "<div class='error_msg'>incorrect username and password</div>";
   }

}
  ?>
    <h1>LOGIN HERE</h1>
    <hr>
    <form id="Login" action="" method="post">

        <div class="form-group">


            <input type="text" class="form-control" id="Username" name="username" placeholder=" Username">

        </div>

        <div class="form-group">

            <input type="password" class="form-control" id="Password" name="password" placeholder="Password">

        </div>
        <div class="forgot">
        <a href="#">Forgot password?</a>
</div>
    <button type="submit" name="login" class="btn btn-primary">Login</button>

    </form>
    </div>

</div></div></div>


</body>
</html>
