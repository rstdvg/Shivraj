-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2019 at 03:15 PM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `contract`
--

-- --------------------------------------------------------

--
-- Table structure for table `addemployee`
--

CREATE TABLE `addemployee` (
  `id` int(20) NOT NULL,
  `e_id` varchar(255) NOT NULL,
  `e_name` varchar(255) NOT NULL,
  `e_gender` varchar(255) NOT NULL,
  `e_age` varchar(255) NOT NULL,
  `e_type` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `addmaterial`
--

CREATE TABLE `addmaterial` (
  `id` int(20) NOT NULL,
  `m_id` varchar(255) NOT NULL,
  `m_name` varchar(255) NOT NULL,
  `m_dos` varchar(255) NOT NULL,
  `m_type` varchar(255) NOT NULL,
  `m_weighing` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `addmaterial`
--

INSERT INTO `addmaterial` (`id`, `m_id`, `m_name`, `m_dos`, `m_type`, `m_weighing`) VALUES
(1, 'm123', 'cement', '2019-02-21', 'cement', '30 bags');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `role` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `username`, `password`, `role`) VALUES
(100, 'admin', 'admin@123', 'admin'),
(107, 'nagu', '123456', 'supervisor'),
(108, 'shivu', 'shivu234', 'supervisor');

-- --------------------------------------------------------

--
-- Table structure for table `materialusage`
--

CREATE TABLE `materialusage` (
  `id` int(20) NOT NULL,
  `mu_id` varchar(255) NOT NULL,
  `mu_name` varchar(255) NOT NULL,
  `mu_date` varchar(255) NOT NULL,
  `mu_stockin` varchar(255) NOT NULL,
  `mu_stockout` varchar(255) NOT NULL,
  `mu_remaining` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `materialusage`
--

INSERT INTO `materialusage` (`id`, `mu_id`, `mu_name`, `mu_date`, `mu_stockin`, `mu_stockout`, `mu_remaining`) VALUES
(1, 'm123', 'cement', '2019-02-09', '10bags', '8bags', '2bags'),
(2, 'm143', 'iron', '2019-02-09', '10 tons', '8 tons', '2 tons'),
(3, 'c123', 'cement', '2019-02-12', '10', '8', '2'),
(5, '123', 'cement', '2019-02-20', '2', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `newcontract`
--

CREATE TABLE `newcontract` (
  `id` int(20) NOT NULL,
  `c_name` varchar(255) NOT NULL,
  `c_nature` varchar(255) NOT NULL,
  `c_place` varchar(255) NOT NULL,
  `c_noe` varchar(255) NOT NULL,
  `c_sd` varchar(255) NOT NULL,
  `c_ed` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `newcontract`
--

INSERT INTO `newcontract` (`id`, `c_name`, `c_nature`, `c_place`, `c_noe`, `c_sd`, `c_ed`) VALUES
(7, 'building', 'poundation', 'ramanagara', '6', '2019-02-09', '2019-02-12'),
(8, 'building', 'poundation', 'ramanagara', '6', '2019-02-09', '2019-02-12'),
(14, 'road ', 'stone crushing', 'hadadi road', '15', '2019-02-11', '2019-02-15'),
(15, 'road ', 'stone crushing', 'hadadi road', '15', '2019-02-11', '2019-02-15'),
(16, 'road ', 'stone crushing', 'hadadi road', '15', '2019-02-11', '2019-02-15'),
(17, 'drainage path', 'digging', 'srinivasanagara', '5', '2019-02-09', '2019-02-11'),
(18, 'bridge', 'abc', 'davangere', '10', '2019-02-11', '2019-02-12'),
(19, 'road contract', 'stone bedding', 'hadadi road', '15', '2019-02-13', '2019-02-19'),
(22, 'road contract', 'road matting ', 'davanagere', '34', '2019-02-21', '2019-02-28');

-- --------------------------------------------------------

--
-- Table structure for table `supervisior`
--

CREATE TABLE `supervisior` (
  `id` int(20) NOT NULL,
  `s_id` varchar(255) NOT NULL,
  `s_name` varchar(255) NOT NULL,
  `s_password` varchar(255) NOT NULL,
  `s_age` varchar(255) NOT NULL,
  `s_experience` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `supervisior`
--

INSERT INTO `supervisior` (`id`, `s_id`, `s_name`, `s_password`, `s_age`, `s_experience`) VALUES
(9, '100', 'nagu', '123456', '20', '2'),
(10, 'S1234', 'shivu', 'shivu234', '25', ''),
(11, 'asdas', 'sdf', 'sd', '4132', 'dcvf');

-- --------------------------------------------------------

--
-- Table structure for table `uploadreport`
--

CREATE TABLE `uploadreport` (
  `id` int(20) NOT NULL,
  `r_id` varchar(255) NOT NULL,
  `r_name` varchar(255) NOT NULL,
  `r_date` varchar(255) NOT NULL,
  `r_time` varchar(255) NOT NULL,
  `r_noe` varchar(255) NOT NULL,
  `r_work` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `uploadreport`
--

INSERT INTO `uploadreport` (`id`, `r_id`, `r_name`, `r_date`, `r_time`, `r_noe`, `r_work`) VALUES
(3, 'r123', 'road report', '2019-02-21', '12:50', '25', 'half');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `addemployee`
--
ALTER TABLE `addemployee`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `addmaterial`
--
ALTER TABLE `addmaterial`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `materialusage`
--
ALTER TABLE `materialusage`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newcontract`
--
ALTER TABLE `newcontract`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `supervisior`
--
ALTER TABLE `supervisior`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `uploadreport`
--
ALTER TABLE `uploadreport`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `addemployee`
--
ALTER TABLE `addemployee`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `addmaterial`
--
ALTER TABLE `addmaterial`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=109;

--
-- AUTO_INCREMENT for table `materialusage`
--
ALTER TABLE `materialusage`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `newcontract`
--
ALTER TABLE `newcontract`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `supervisior`
--
ALTER TABLE `supervisior`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `uploadreport`
--
ALTER TABLE `uploadreport`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
