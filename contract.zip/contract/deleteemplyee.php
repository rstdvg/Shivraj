<?php
require_once '../contract/Lib/config.php';
if(isset($_GET['id'])) {

  $eid = 'e_id';
  $id = $_GET['id'];
  $table = 'addemployee';

  if ($contract->deleteValue($table,$eid,$id)) {
    header("location:viewemployee.php");
  }
}
?>