<?php

class rstClass {
	private $db;

  function __construct($db_con){
    $this->db = $db_con;
  }

public function login($uname,$pwd,$table){
    try {
      $stmt = $this->db->prepare("SELECT * FROM $table WHERE username=:uname AND password=:pwd");
      $stmt->bindParam(':uname',$uname);
      $stmt->bindParam(':pwd',$pwd);
      $stmt->execute();
      $result=$stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
}

// add new work
  public function insert_newwork($c_name,$c_nature,$c_place,$c_noe,$c_sd,$c_ed) {
    try {
      $stmt = $this->db->prepare("INSERT INTO newcontract(c_name,c_nature,c_place,c_noe,c_sd,c_ed) VALUES (:c_name,:c_nature,:c_place,:c_noe,:c_sd,:c_ed)");
       $stmt->bindParam(':c_name',$c_name);
      $stmt->bindParam(':c_nature',$c_nature);
      $stmt->bindParam(':c_place',$c_place);
      $stmt->bindParam(':c_noe',$c_noe);
      $stmt->bindParam(':c_sd',$c_sd);
      $stmt->bindParam(':c_ed',$c_ed);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

public function fetch_newcontract_details($table) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }


public function insert_supervisior($s_id,$s_name,$s_password,$s_age,$s_experience) {
    try {
      $stmt = $this->db->prepare("INSERT INTO supervisior(s_id,s_name,s_password,s_age,s_experience) VALUES (:s_id,:s_name,:s_password,:s_age,:s_experience)");
       $stmt->bindParam(':s_id',$s_id);
      $stmt->bindParam(':s_name',$s_name);
      $stmt->bindParam(':s_password',$s_password);
      $stmt->bindParam(':s_age',$s_age);
      $stmt->bindParam(':s_experience',$s_experience);
      $stmt->execute();
      return $stmt;   
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

  public function insert_login($u_email,$u_password,$role){
    try {
      $stmt = $this->db->prepare("INSERT INTO login(email,password,role) VALUES (:email,:password,:role)");
      $stmt->bindParam(':email',$u_email);
      $stmt->bindParam(':password',$u_password);
      $stmt->bindParam(':role',$role);
      $stmt->execute();
      return $stmt;   
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }

  public function insert_material($m_id,$m_name,$m_dos,$m_type,$m_weighing) {
    try {
      $stmt = $this->db->prepare("INSERT INTO addmaterial(m_id,m_name,m_dos,m_type,m_weighing) VALUES (:m_id,:m_name,:m_dos,:m_type,:m_weighing)");
       $stmt->bindParam(':m_id',$m_id);
      $stmt->bindParam(':m_name',$m_name);
      $stmt->bindParam(':m_dos',$m_dos);
      $stmt->bindParam(':m_type',$m_type);
       $stmt->bindParam(':m_weighing',$m_weighing);
      $stmt->execute();
      return $stmt;   
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }


public function fetch_material_details($table) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }

  public function insert_employee($e_id,$e_name,$e_gender,$e_age,$e_type){
    try {
      $stmt = $this->db->prepare("INSERT INTO addemployee(e_id,e_name,e_gender,e_age,e_type) VALUES (:e_id,:e_name,:e_gender,:e_age,:e_type)");
       $stmt->bindParam(':e_id',$e_id);
      $stmt->bindParam(':e_name',$e_name);
      $stmt->bindParam(':e_gender',$e_gender);
      $stmt->bindParam(':e_age',$e_age);
       $stmt->bindParam(':e_type',$e_type);
      $stmt->execute();
      return $stmt;   
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

 public function deleteValue($table,$eid,$id) {
    try {
      $stmt = $this->db->prepare("DELETE FROM $table WHERE $eid=:id");
      $stmt->bindParam(':id',$id);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }
  public function delete_materialValue($table,$mid,$id) {
    try {
      $stmt = $this->db->prepare("DELETE FROM $table WHERE $mid=:id");
      $stmt->bindParam(':id',$id);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }

public function fetch_employee_details($table) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }

  public function fetch_material($table) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }


 public function insert_usage($mu_id,$mu_name,$mu_date,$mu_stockin,$mu_stockout,$mu_remaining){
    try {
      $stmt = $this->db->prepare("INSERT INTO materialusage(mu_id,mu_name,mu_date,mu_stockin,mu_stockout,mu_remaining) VALUES (:mu_id,:mu_name,:mu_date,:mu_stockin,:mu_stockout,:mu_remaining)");
       $stmt->bindParam(':mu_id',$mu_id);
      $stmt->bindParam(':mu_name',$mu_name);
      $stmt->bindParam(':mu_date',$mu_date);
      $stmt->bindParam(':mu_stockin',$mu_stockin);
       $stmt->bindParam(':mu_stockout',$mu_stockout);
      $stmt->bindParam(':mu_remaining',$mu_remaining);
      $stmt->execute();
      return $stmt;   
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }


public function fetch_checkmaterial_details($table) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }


public function insert_report($r_id,$r_name,$r_date,$r_time,$r_noe,$r_work){
    try {
      $stmt = $this->db->prepare("INSERT INTO uploadreport(r_id,r_name,r_date,r_time,r_noe,r_work) VALUES (:r_id,:r_name,:r_date,:r_time,:r_noe,:r_work)");
      $stmt->bindParam(':r_id',$r_id);
      $stmt->bindParam(':r_name',$r_name);
      $stmt->bindParam(':r_date',$r_date);
      $stmt->bindParam(':r_time',$r_time);
      $stmt->bindParam(':r_noe',$r_noe);
      $stmt->bindParam(':r_work',$r_work);
      $stmt->execute();
      return $stmt;   
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }


public function fetch_report_details($table) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }

public function fetch_usage_details($table) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }

  public function single_report_delete($id,$table) {
    try {
      $stmt = $this->db->prepare("DELETE FROM $table WHERE r_id=:id");
      $stmt->bindParam(':id',$id);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }
  









// Fetch Values Generally
  

// Retrieve specefic field from specefic table: for id generation
  public function fetchLastIntered($table, $id) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table ORDER BY $id DESC LIMIT 1");
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

// Select Config Table
  public function SltRst_Config($projectname,$projecttype,$ipaddress,$internetstatus,$username, $password,$role,$status,$logintime,$table) {
    try {
      $stmt = $this->db->prepare("SELECT project_name,project_type,ip_address,internet_status,username,password,role,status,login_time FROM $table");
      $stmt->bindParam(':project_name',$projectname);
      $stmt->bindParam(':project_type',$projecttype);
      $stmt->bindParam(':ip_address',$ipaddress);
      $stmt->bindParam(':internet_status',$internetstatus);
      $stmt->bindParam(':username',$username);
      $stmt->bindParam(':password',$password);
      $stmt->bindParam(':role',$role);
      $stmt->bindParam(':status',$status);
      $stmt->bindParam(':login_time',$logintime);
      $stmt->execute();
      $result = $stmt->fetch();

      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }



  // retrieve all specefic table fields : for edit purpose
  public function editView($table, $cid, $id) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table WHERE $cid=:id");
      $stmt->bindParam(':id',$id);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }
  // Select tables end End Delete Tables Begins


  //General Delet Table
  public function deleteValueTest($table,$id) {
    try {
      $stmt = $this->db->prepare("DELETE FROM $table where id=$id");
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }

//select general table
  public function StockOut($table) {
    try {
      $stmt = $this->db->prepare("SELECT count(*) FROM $table");
      $stmt->execute();
      $rows = $stmt->fetchColumn();
      return $rows;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }




  
// Delete Tables End and Update tables begins

//update begins
  // update data for config table

  public function UpdateRst_config($projectid,$projectname,$projecttype,$ipaddress,$internetstatus,$username,$password,$role,$status,
    $logintime) {
    try {
      $stmt = $this->db->prepare("UPDATE config SET project_name=:project_name,project_type=:project_type,ip_address=:ip_address,internet_status=:internet_status,username=:username,password=:password,
      role=:role,status=:status,login_time=:login_time WHERE project_id=:project_id");
      $stmt->bindParam(':project_id', $projectid);
      $stmt->bindParam(':project_name', $projectname);
      $stmt->bindParam(':project_type', $projecttype);
      $stmt->bindParam(':ip_address', $ipaddress);
      $stmt->bindParam(':internet_status', $internetstatus);
      $stmt->bindParam(':username', $username);
      $stmt->bindParam(':password', $password);
      $stmt->bindParam(':role', $role);
      $stmt->bindParam(':status', $status);
      $stmt->bindParam(':login_time', $login_time);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }

  // update data for paticipant
  public function UpdateRst_Participant($pid,$pname,$age,$address,$religion,$education,$occupation,$gravida,$trimester,$familytype,$familyincome,$socioecoclass,$rationcardtype,$diet) {
    try {
      $stmt = $this->db->prepare("UPDATE participant SET p_name=:p_name,age=:age,address=:address,religion=:religion,education=:education,occupation=:occupation,gravida=:gravida,trimester=:trimester,family_type=:family_type,family_income=:family_income,socio_eco_class=:socio_eco_class,ration_card_type=:ration_card_type,diet=:diet WHERE p_id=:p_id");
      $stmt->bindParam(':p_name', $pname);
      $stmt->bindParam(':age', $age);
      $stmt->bindParam(':address', $address);
      $stmt->bindParam(':religion', $religion);
      $stmt->bindParam(':education', $education);
      $stmt->bindParam(':occupation', $occupation);
      $stmt->bindParam(':gravida', $gravida);
      $stmt->bindParam(':trimester', $trimester);
      $stmt->bindParam(':family_type', $familytype);
      $stmt->bindParam(':family_income', $familyincome);
      $stmt->bindParam(':socio_eco_class', $socioecoclass);
      $stmt->bindParam(':ration_card_type', $ration_card_type);
      $stmt->bindParam(':diet', $diet);
      $stmt->bindParam(':p_id', $pid);

      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }
  
      // update data for question_tbl
  public function UpdateRst_Qtntbl($qid,$qname,$opt1,$opt2,$opt3,$opt4,$opt5,$opt6,$opt7,$opt8,$status) {
    try {
      $stmt = $this->db->prepare("UPDATE question_tbl SET q_name=:q_name,opt_1=:opt_1,opt_2=:opt_2,opt_3=:opt_3,opt_4=:opt_4,opt_5=:opt_5,opt_6=:opt_6,opt_7=:opt_7,opt_8=:opt_8,status=:status WHERE q_id=:q_id" );

      $stmt->bindParam(':q_name', $qname);
      $stmt->bindParam(':opt_1', $opt1);
      $stmt->bindParam(':opt_2', $opt2);
      $stmt->bindParam(':opt_3', $opt3);
      $stmt->bindParam(':opt_4', $opt4);
      $stmt->bindParam(':opt_5', $opt5);
      $stmt->bindParam(':opt_6', $opt6);
      $stmt->bindParam(':opt_7', $opt7);
      $stmt->bindParam(':opt_8', $opt8);
      $stmt->bindParam(':status', $status);
      $stmt->bindParam(':q_id', $qid);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }
  
      // update data for result_tbl
  public function UpdateRst_resulttbl($rid,$pid,$qid,$options,$longans,$createddate) {
    try {
      $stmt = $this->db->prepare("UPDATE result_tbl SET q_id=:q_id,p_id=:p_id,options=:options,created_date=:created_date WHERE result_id=:result_id");
      $stmt->bindParam(':q_id', $qid);
      $stmt->bindParam(':p_id', $pid);
      $stmt->bindParam(':options', $options);
      $stmt->bindParam(':long_ans', $longans);
      $stmt->bindParam(':created_date', $createddate);
      $stmt->bindParam(':result_id', $rid);

      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }  






  //general update data for brand entry
  public function updatersttest($uid,$username,$password) {
    try {
      $stmt = $this->db->prepare("UPDATE test SET username=:username password=:password WHERE id=:uid");
      $stmt->bindParam(':username', $username);
      $stmt->bindParam(':password', $password);
      $stmt->bindParam(':uid', $uid);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e) {
      echo $e->getMessage();
    }
  }




// test tables related
public function insertTest($username,$password,$table) {
    try {
      $stmt = $this->db->prepare("INSERT INTO $table (username,password) VALUES (:username,:password)");
      $stmt->bindParam(':username',$username);
      $stmt->bindParam(':password',$password);
       $stmt->execute();
      return $stmt;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }


}

?>