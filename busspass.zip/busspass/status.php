<?php
 require_once 'RSTLibpass/config.php';
 $table='register';
if(isset($_GET['user_id'])){
$status=$_GET['user_id'];
$result=$buspass->fetch_status($table,$status);

$st=$result['status'];
if($st=='0')
{
$status2=1;
}
elseif($st=='1')
{
$status2=-1;
}
elseif($st=='-1')
{
$status2=0;
}
echo $status2;
$results=$buspass->update_status($table,$status,$status2);
header("Location:applied.php");

}

?>