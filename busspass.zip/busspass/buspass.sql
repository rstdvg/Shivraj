-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 20, 2019 at 11:52 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buspass`
--

-- --------------------------------------------------------

--
-- Table structure for table `approve`
--

CREATE TABLE `approve` (
  `id` int(20) NOT NULL,
  `u_name` varchar(225) NOT NULL,
  `u_number` varchar(225) NOT NULL,
  `u_email` varchar(225) NOT NULL,
  `u_password` varchar(225) NOT NULL,
  `u_address` varchar(225) NOT NULL,
  `u_district` varchar(225) NOT NULL,
  `u_iname` varchar(225) NOT NULL,
  `u_iaddress` varchar(225) NOT NULL,
  `u_semister` varchar(225) NOT NULL,
  `u_branch` varchar(225) NOT NULL,
  `u_adnum` varchar(225) NOT NULL,
  `u_from` varchar(225) NOT NULL,
  `u_to` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `approve`
--

INSERT INTO `approve` (`id`, `u_name`, `u_number`, `u_email`, `u_password`, `u_address`, `u_district`, `u_iname`, `u_iaddress`, `u_semister`, `u_branch`, `u_adnum`, `u_from`, `u_to`) VALUES
(2, 'shivu', '09535739814', 'nagubv5@gmail.com', 'werwer', 'Davnegere', 'wer', 'werwe', 'Davnegere', 'werwe', 'wer', 'rt', 'rer', 'ujkhj'),
(3, 'shivu', '09535739814', 'nagubv5@gmail.com', 'asd', 'Davnegere', 'asd', 'asdasd', 'Davnegere', 'asdasd', 'asdas', 'asdasd', 'asdas', 'asdasd');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(20) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `role` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `password`, `role`) VALUES
(1, 'shivu@gmail.com', '12345678', 'student'),
(2, 'shivrajarya7@gmail.com', 'shivarajn', 'student'),
(3, '', '', 'student'),
(4, 'kumara123@gmail.com', '123456', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(20) NOT NULL,
  `u_name` varchar(225) NOT NULL,
  `u_number` varchar(225) NOT NULL,
  `u_email` varchar(225) NOT NULL,
  `u_password` varchar(225) NOT NULL,
  `u_address` varchar(225) NOT NULL,
  `u_district` varchar(225) NOT NULL,
  `u_iname` varchar(225) NOT NULL,
  `u_iaddress` varchar(225) NOT NULL,
  `u_semister` varchar(225) NOT NULL,
  `u_branch` varchar(225) NOT NULL,
  `u_adnum` varchar(225) NOT NULL,
  `u_from` varchar(225) NOT NULL,
  `u_to` varchar(225) NOT NULL,
  `status` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `u_name`, `u_number`, `u_email`, `u_password`, `u_address`, `u_district`, `u_iname`, `u_iaddress`, `u_semister`, `u_branch`, `u_adnum`, `u_from`, `u_to`, `status`) VALUES
(33, 'shivu', '7795330096', 'shivu@gmail.com', '12345678', 'address', 'davangere', 'radiant', 'dvg', '7', 'mca', '10122', 'davangere', 'harihara', 1),
(34, 'shivu', '7795330096', 'shivu@gmail.com', '123456', 'address', 'davangere', 'radiant', 'dvg', '7', 'mca', '10122', 'davangere', 'harihara', -1),
(35, 'shivu', '7795330096', 'shivu@gmail.com', '12345678', 'address', 'davangere', 'radiant', 'dvg', '7', 'mca', '10122', 'davangere', 'harihara', 0),
(36, 'shivaraja N', '9916478762', 'shivrajarya7@gmail.com', 'shivarajn', 'davanagere', 'davanagere', 'UBDT', 'davanagere', '6', 'mca', '4ub16mca87', 'anagodu', 'davanagere', 1),
(38, 'kumara varma', '9154786285', 'kumara123@gmail.com', '123456', 'Davnegere', 'davangere', 'ubdtce', 'Davnegere', '4th', 'MCA', '1nz17mca73', 'davanagere', 'yamaloka', 0);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approve`
--
ALTER TABLE `approve`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approve`
--
ALTER TABLE `approve`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
