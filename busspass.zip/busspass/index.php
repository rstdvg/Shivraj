<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="css/jquery.min.js"></script>
  
   <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css1/style.css">   
   <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

		
	</style>
</head>
<?php
require_once 'RSTLibpass/config.php';
$table="login";
if(isset($_POST['login']))   // button 
{
$email=$_POST['email'];
$password=$_POST['password'];

if($result=$buspass->fetch_login($table,$email,$password)){
echo $r_email=$result['email'];
echo $r_password=$result['password'];
echo $r_role=$result['role'];

  if ($r_email==$email && $r_password==$password) {
   session_start();
   if($r_role=="admin")
   {
    $_SESSION['user_name']=$r_email;
    header("location:adminboard.php");
   }
   elseif($r_role=="controller")
    {
    $_SESSION['user_name']=$r_email;
    header("location:Controller.php");
    }
    elseif($r_role=="student")
    {
    $_SESSION['user_name']=$r_email;
    header("location:swelcome.php");
    }
  }
}
else{
    
    echo "<div class='error_msg' style='color:red;text-align:center;padding-top:50px;'>incorrect username and password</div>";
   }


}
  ?>


<body>
	<div class="container">
    <div class="row">
    <div class="form_bg">

    <form  action="" method="post" >
    <h2 class="text-center">Login Page</h2>
    <br/>
    <div class="form-group">
    <input type="email" class="form-control" id="userid" placeholder="User email id" name="email">
    </div>
    <div class="form-group">
    <input type="password" class="form-control" id="pwd" placeholder="Password" name="password">
    </div>
     <br/>
     <div class="align-center">
    <a href="register.php" class="btn btn-primary btn-md"  style="float: left">Register Now </a> 
<button type="submit" class="btn btn-success btn-md" name="login" style="float: right">Login</button>    
    </div>
            </form>
        </div>
    </div>
</div>
        
        

</body>
</html>