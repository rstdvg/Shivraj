-- phpMyAdmin SQL Dump
-- version 4.8.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 21, 2019 at 09:07 AM
-- Server version: 10.1.34-MariaDB
-- PHP Version: 7.2.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `buspass`
--

-- --------------------------------------------------------

--
-- Table structure for table `approve`
--

CREATE TABLE `approve` (
  `id` int(20) NOT NULL,
  `u_name` varchar(225) NOT NULL,
  `u_number` varchar(225) NOT NULL,
  `u_email` varchar(225) NOT NULL,
  `u_password` varchar(225) NOT NULL,
  `u_address` varchar(225) NOT NULL,
  `u_district` varchar(225) NOT NULL,
  `u_iname` varchar(225) NOT NULL,
  `u_iaddress` varchar(225) NOT NULL,
  `u_semister` varchar(225) NOT NULL,
  `u_branch` varchar(225) NOT NULL,
  `u_adnum` varchar(225) NOT NULL,
  `u_from` varchar(225) NOT NULL,
  `u_to` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `approve`
--

INSERT INTO `approve` (`id`, `u_name`, `u_number`, `u_email`, `u_password`, `u_address`, `u_district`, `u_iname`, `u_iaddress`, `u_semister`, `u_branch`, `u_adnum`, `u_from`, `u_to`) VALUES
(2, 'shivu', '09535739814', 'nagubv5@gmail.com', 'werwer', 'Davnegere', 'wer', 'werwe', 'Davnegere', 'werwe', 'wer', 'rt', 'rer', 'ujkhj'),
(3, 'shivu', '09535739814', 'nagubv5@gmail.com', 'asd', 'Davnegere', 'asd', 'asdasd', 'Davnegere', 'asdasd', 'asdas', 'asdasd', 'asdas', 'asdasd');

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE `login` (
  `id` int(20) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(225) NOT NULL,
  `role` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `login`
--

INSERT INTO `login` (`id`, `email`, `password`, `role`) VALUES
(2, 'controller@gmail.com', 'controller@123', 'controller'),
(3, 'admin@gmail.com', 'admin@123', 'admin'),
(4, 'shivu@gmail.com', '123456', 'student'),
(5, 'shivu@gmail.com', '123456', 'student'),
(6, 'p@gmail.com', '123456', 'student'),
(7, 'shivu11@gmail.com', '123456', 'student'),
(8, 'shivu11@gmail.com', '', 'student'),
(9, 'raju@gmail.com', '123456', 'student'),
(10, 'kumar@gmail.com', '123456789', 'student');

-- --------------------------------------------------------

--
-- Table structure for table `register`
--

CREATE TABLE `register` (
  `id` int(20) NOT NULL,
  `u_name` varchar(225) NOT NULL,
  `u_number` varchar(225) NOT NULL,
  `u_email` varchar(225) NOT NULL,
  `u_password` varchar(225) NOT NULL,
  `u_address` varchar(225) NOT NULL,
  `u_district` varchar(225) NOT NULL,
  `u_iname` varchar(225) NOT NULL,
  `u_iaddress` varchar(225) NOT NULL,
  `u_semister` varchar(225) NOT NULL,
  `u_branch` varchar(225) NOT NULL,
  `u_adnum` varchar(225) NOT NULL,
  `u_from` varchar(225) NOT NULL,
  `u_to` varchar(225) NOT NULL,
  `status` int(11) DEFAULT NULL,
  `img` longblob,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `register`
--

INSERT INTO `register` (`id`, `u_name`, `u_number`, `u_email`, `u_password`, `u_address`, `u_district`, `u_iname`, `u_iaddress`, `u_semister`, `u_branch`, `u_adnum`, `u_from`, `u_to`, `status`, `img`, `date`) VALUES
(33, 'shivu', '7795330096', 'shivu@gmail.com', '12345678', 'address', 'davangere', 'radiant', 'dvg', '7', 'mca', '10122', 'davangere', 'harihara', 1, NULL, NULL),
(34, 'shivu', '7795330096', 'shivu@gmail.com', '123456', 'address', 'davangere', 'radiant', 'dvg', '7', 'mca', '10122', 'davangere', 'harihara', -1, NULL, NULL),
(35, 'shivu', '7795330096', 'shivu@gmail.com', '12345678', 'address', 'davangere', 'radiant', 'dvg', '7', 'mca', '10122', 'davangere', 'harihara', 0, NULL, NULL),
(36, 'shivu', '7795330096', 'shivu@gmail.com', '123456', 'address', 'davangere', 'radiant', 'dvg', '7', 'mca', '10122', 'davangere', 'harihara', 0, NULL, NULL),
(37, 'shivu', '7795330096', 'shivu@gmail.com', '123456', 'address', 'davangere', 'radiant', 'dvg', '7', 'mca', '10122', 'davangere', 'harihara', 0, NULL, NULL),
(38, 'prveen ', '7795330296', 'p@gmail.com', '123456', 'address', 'davangere', 'radiant', 'dvg', '7', 'mca', '10122', 'davangere', 'harihara', 1, NULL, '2019-02-21'),
(39, 'naguu', '7795330096', 'shivu11@gmail.com', '123456', 'davangere', 'davangere', 'radiant', 'dvg', '7', 'mca', '101222', 'davangere', 'harihara', 1, '', '2019-02-21'),
(40, 'naguu', '7795330096', 'shivu11@gmail.com', '', 'davangere', 'davangere', 'radiant', 'dvg', '7', 'mca', '101222', 'davangere', 'harihara', 1, 0x616b736869692e706e67, '2019-02-21'),
(41, 'raju', '77795330296', 'raju@gmail.com', '123456', 'davangere', 'davangere', 'radiant', 'dvg', '8', 'mca', '10122', 'davangere', 'harihara', 1, 0x6e61676172616a207369722e6a7067, '2019-02-21'),
(42, 'kumar', '777950033695', 'kumar@gmail.com', '123456789', 'address', 'davangere', 'radiant', 'dvg', '7', 'mca', '101222', 'davangere', 'harihara', 1, 0x6b756d61722e706e67, '2019-02-21');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `approve`
--
ALTER TABLE `approve`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `login`
--
ALTER TABLE `login`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `register`
--
ALTER TABLE `register`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `approve`
--
ALTER TABLE `approve`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `login`
--
ALTER TABLE `login`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `register`
--
ALTER TABLE `register`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
