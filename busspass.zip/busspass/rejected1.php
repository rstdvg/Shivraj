<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Controller-Dashboard</title>

    <!-- Bootstrap core CSS-->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
    <link href="css/sb-admin.css" rel="stylesheet">
    <style type="text/css">
      

th{
  text-align: center;
  text-transform: uppercase;
}

    </style>

  </head>
  <?php
 require_once 'RSTLibpass/config.php';
  $table='register';
  $status=-1;
 $result=$buspass->fetch_rejected($table,$status);
 ?>

  <body id="page-top">

    <nav class="navbar navbar-expand navbar-dark bg-dark static-top">



      <a class="navbar-brand mr-1" href="Controller.php">Controller Dashboard</a>

      <button class="btn btn-link btn-sm text-white order-1 order-sm-0" id="sidebarToggle" href="#">
        <i class="fas fa-bars"></i>


      </button>


      <!-- Navbar Search -->

      <!-- Navbar -->
      <ul class="navbar-nav ml-auto ml-md-0">
         <h2 style="font-weight: bold;color: white; margin-left:300px;">BUSPASS MANAGEMENT SYSTEM</h2>
        
       
      </ul>

    </nav>

    <div id="wrapper">

      <!-- Sidebar -->
        <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="Controller.php">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span>Dashboard</span>
          </a>
        </li>
          <li class="nav-item">
          <a class="nav-link" href="approved1.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Approved</span></a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="rejected1.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Rejected</span></a>
        </li>
       
         <li class="nav-item">
          <a class="nav-link" href="logout.php">
            <i class="fas fa-fw fa-chart-area"></i>
            <span>Logout</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">

          <!-- Breadcrumbs-->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="#">Dashboard</a>
            </li>
            <li class="breadcrumb-item active">View Rejected Requests</li>
          </ol>

          <div class="container">
 
  <!-- Trigger the modal with a button -->
  
  <!-- Modal -->
  <div class="modal fade" id="myModal" role="dialog">
    <div class="modal-dialog">
    
      <!-- Modal content-->
      <div class="modal-content" style="width: 645px; margin-left: -50px;">
        <div class="modal-header">
          
          <h4 class="modal-title">View Rejected Student Details</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>

        </div>
        <div class="modal-body" id="student_detail">




        

        </div>
        <div class="modal-footer">

      
      </div>
      
    </div>
  </div>
  
</div>



 <table class="table table-bordered" cellspacing="0" width="100%">
<thead class="thead-dark">
      <tr>
        <th>Name</th>
        <th>Number</th>
        <th>Dist</th>
        <th>Institute</th>
        <th>Institute Address</th>
        
        <th>From</th>
        <th>To</th>
       
        <th>Action</th>
        <th>Status</th>
      </tr>
    </thead>
       <?php
       foreach ($result as $value) {
   
        ?>  

       <tbody>

               <td><?php echo $value['u_name']; ?></td>
                <td><?php echo $value['u_number']; ?></td>
                <td><?php echo $value['u_district']; ?></td>
                <td><?php echo $value['u_iname']; ?></td>
                <td><?php echo $value['u_iaddress']; ?></td>
                   
                <td><?php echo $value['u_from']; ?></td>
                <td><?php echo $value['u_to']; ?></td>
               
                <td><button type="button" class="btn btn-success btn-sm view_data" data-toggle="modal" data-target="#myModal" id="<?php echo $value["id"]; ?>">View</button>
            </td>
            <?php $status=$value['status']; ?>

          <td>
          <?php if(($status)=='-1'){ ?>
             <span style="color:red;font-weight: bold;">Rejected</span>
         <?php } ?>
           </td>
        
</tbody>

     <?php  } ?>
     </table>
<script>  
 $(document).ready(function(){  
      $('.view_data').click(function(){  
           var student_id = $(this).attr("id");
      // alert(student_id); 
           $.ajax({  
                url:"select.php",  
                method:"post",  
                data:{student1_id:student_id},  
                success:function(data){  
                     $('#student_detail').html(data);  
                     $('#myModal').modal("show");  
                }  
           });  
      });  
 });  
 </script>
    


            <script type="text/javascript">
              $(document).ready(function () {
      
    $("#myBtn").click(function(){
         $('#myModal').modal('show');
    });
});
            </script>




         





        <!-- Sticky Footer -->
        <footer class="sticky-footer">
          <div class="container my-auto">
            <div class="copyright text-center my-auto">
              <span>.....</span>
            </div>
          </div>
        </footer>

      </div>
      <!-- /.content-wrapper -->

    </div>
    <!-- /#wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
      <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
            <button class="close" type="button" data-dismiss="modal" aria-label="Close">
              <span aria-hidden="true">×</span>
            </button>
          </div>
          <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
          <div class="modal-footer">
            <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
            <a class="btn btn-primary" href="login.html">Logout</a>
          </div>
        </div>
      </div>
    </div>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Page level plugin JavaScript-->
    <script src="vendor/chart.js/Chart.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin.min.js"></script>

    <!-- Demo scripts for this page-->
    <script src="js/demo/datatables-demo.js"></script>
    <script src="js/demo/chart-area-demo.js"></script>

  </body>

</html>
