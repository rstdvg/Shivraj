<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="css/jquery.min.js"></script>
  
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css1/style.css">	
   <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">
    <style type="text/css">
        .aq1{
               margin-top: 218px;
    margin-left: 357px;

        }
    </style>

    <!-- Custom styles for this template-->
</head>
  
<body>
	<div class="container">
    <div class="row">
       <div class="aq1">
        <img src="img/aq1.png" style="width: 41%;
    height: 54%;margin-left: 87px;"><br>
       <h3>Registrartion completed Successfully</h3>
        <a href="index.php"> <button class="btn btn-default center-block" style="margin-left: 55%">Back</button></a> </div>

   </div>
       
    </div>
</div>
        
        

</body>
</html>



