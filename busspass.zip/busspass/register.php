<!DOCTYPE html>
<html>
<head>
	<title></title>
	<script src="css/jquery.min.js"></script>
  
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css1/style.css">	
   <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom fonts for this template-->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <!-- Page level plugin CSS-->
    <link href="vendor/datatables/dataTables.bootstrap4.css" rel="stylesheet">

    <!-- Custom styles for this template-->
</head>
   <?php
require_once 'RSTLibpass/config.php';
if(isset($_POST['register']))   // button 
{
$u_name=$_POST['u_name'];
$u_number=$_POST['u_number'];
$u_email=$_POST['u_email'];
$u_password=$_POST['u_password'];
$u_address=$_POST['u_address'];
$u_district=$_POST['u_district'];
$u_iname=$_POST['u_iname'];
$u_iaddress=$_POST['u_iaddress'];
$u_semister=$_POST['u_semister'];
$u_branch=$_POST['u_branch'];
$u_adnum=$_POST['u_adnum'];
$u_from=$_POST['u_from'];
$u_to=$_POST['u_to'];
$u_status=$_POST['status'];


$file=$_FILES['file']['name'];
$date=date('Y/m/d');


$fileName=$_FILES['file']['name'];
$fileTempname=$_FILES['file']['tmp_name'];
$fileSize=$_FILES['file']['size'];
$fileError=$_FILES['file']['error'];
$fileType=$_FILES['file']['type'];
$fileExt=explode('.', $fileName);
$ActualExt=strtolower(end($fileExt));
$allowed=array('jpg','png','JPEG');

  if(in_array($ActualExt,$allowed)){
    if($fileError==0){
        if($fileSize<350000){

       $fileDesti='../busspass/uploads/'.$fileName;
       move_uploaded_file($fileTempname,$fileDesti);

        }else{
        $message = "File Is Too Big";
    echo "<script type='text/javascript'>alert('$message');</script>";
        }
        
    }else{
        $message = "Uploading Error";
    echo "<script type='text/javascript'>alert('$message');</script>";
    }

}
else{
    $message = "INVALID FILE";
    echo "<script type='text/javascript'>alert('$message');</script>";
}





$buspass->insert_register($u_name,$u_number,$u_email,$u_password,$u_address,$u_district,$u_iname,$u_iaddress,$u_semister,$u_branch,$u_adnum,$u_from,$u_to,$u_status,$file,$date);
$role=$_POST['u_role'];
$buspass->insert_login($u_email,$u_password,$role);

          header("Location:succesufull.php");

}

  ?>
<body>
	<div class="container">
    <div class="row">
        <div class="form_bg" style="width: 814px;
               height:  587px;">

            <form action="" method="post" enctype="multipart/form-data">
                 <h2 class="text-center">Register Now</h2>

                <br/>
                <div class="row">
                    <div class="col-sm-6 col-md-6 col-lg-6">
                <div class="form-group">
                <input type="text" class="form-control" id="" placeholder="User Name" name="u_name" required>
                </div>
                <div class="form-group">
                <input type="number" class="form-control" id="" placeholder="Contact Number" name="u_number" required>
                </div>

                <div class="form-group">
                <input type="email" class="form-control" id="" placeholder="User Email Id" name="u_email" required>
                </div>
                 <div class="form-group">
                <input type="password" class="form-control" id="" placeholder="Enter your password" name="u_password" required>
                </div>
                  <div class="form-group">
                <input type="text" class="form-control" id="" placeholder="Enter your address" name="u_address" required>
                </div>
                 <div class="form-group">
                <input type="text" class="form-control" id="" placeholder="Enter your district" name="u_district" required>
                </div>
                <div class="form-group">
                <input type="text" class="form-control" id="" placeholder="Institution Name" name="u_iname" required>
                </div>
            </div>
              



                    <div class="col-sm-6 col-md-6 col-lg-6">
                <div class="form-group">
                <input type="text" class="form-control" id="" placeholder="Institution Address" name="u_iaddress" required>
                </div>
                <div class="form-group">
                <input type="text" class="form-control" id="" placeholder="Semister" name="u_semister"required>
                </div>
                <div class="form-group">
                <input type="text" class="form-control" id="" placeholder="Enter Branch" name="u_branch" required>
                </div>
                <div class="form-group">
                <input type="text" class="form-control" id="" placeholder="Admisiion Number" name="u_adnum" required>
                </div>
              <br/>
                <div class="form-group">
                <input type="text" class="form-control" id="" placeholder="From Location" name="u_from" required>
                </div>
                <div class="form-group">
                <input type="text" class="form-control" id="" placeholder="To Location" name="u_to" required>
                </div>

                <div class="form-group" style="display: none;">
                <input type="text" class="form-control" id="" placeholder="To Location" name="u_role" value="student" required>
                </div>

                <div class="form-group" style="display: none;">
                <input type="text" class="form-control" id="" placeholder="To Location" name="status" value="0" required> 
                </div>

                <div class="form-group">
                Upload Photo: <input type="file" name="file" required>
                </div>


            </div>
        </div>



                <br/>
                
                <div class="row" style="float: right;">
                <center><a href="index.php"><p>already have an account ?</p></a></center>    
                <div class="align-center">     
                <button class="btn btn-primary btn-md" style="margin-left: 10px" name="register">Register</button> </div>

            </div>
            </form>
        </div>
    </div>
</div>
        
        

</body>
</html>



