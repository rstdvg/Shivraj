<?php
 require_once 'RSTLibpass/config.php';  
 if(isset($_POST["student1_id"]))  
 {  

      $output = '';  
      $table='register';
      $id=$_POST['student1_id'];
      $student=$buspass->fetch_register($table,$id);
      $output .= '  
      <div class="table-responsive">  
           <table class="table table-bordered">';  
     
           $output .= '  
                <tr>  
                     <td width="30%"><label>Name</label></td>  
                     <td width="70%">'.$student['u_name'].'</td>  
                </tr>  

                
                <tr>  
                     <td width="30%"><label>Number</label></td>  
                     <td width="70%">'.$student['u_number'].'</td>  
                </tr>  
                   <tr>  
                     <td width="30%"><label>Email</label></td>  
                     <td width="70%">'.$student['u_email'].'</td>  
                </tr>
                   <tr>  
                     <td width="30%"><label>Addres</label></td>  
                     <td width="70%">'.$student['u_address'].'</td>  
                </tr>
                <tr>  
                     <td width="30%"><label>District</label></td>  
                     <td width="70%">'.$student['u_district'].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Institute Name</label></td>  
                     <td width="70%">'.$student['u_iname'].'</td>  
                </tr>  
                <tr>  
                     <td width="30%"><label>Institute Address</label></td>  
                     <td width="70%">'.$student['u_iaddress'].' Year</td>  
                </tr>  

                   <tr>  
                     <td width="30%"><label>Semister</label></td>  
                     <td width="70%">'.$student['u_semister'].'</td>  
                </tr>
                <tr>  
                     <td width="30%"><label>From Location</label></td>  
                     <td width="70%">'.$student['u_from'].'</td>  
                </tr>
                <tr>  
                     <td width="30%"><label>To Location</label></td>  
                     <td width="70%">'.$student['u_to'].'</td>  
                </tr> ';  

      $output .= "</table></div>";  
      echo $output;  
 }  
 ?>