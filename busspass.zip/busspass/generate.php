<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
  

	<title>Generate Pass</title>

	<link rel="stylesheet" href="print/css/style.css">
	<link rel="license" href="https://www.opensource.org/licenses/mit-license/">
	<script src="print/js/script.js"></script>
	<script  src="print/js/index.js"></script>
</head>
<?php 
require_once 'RSTLibpass/config.php';
  $pid=$_GET['print_id'];
 $table='register';
 $bresults=$buspass->buspassprint($table,$pid);

$u_name=$bresults['u_name'];
$u_number=$bresults['u_number'];
$u_email=$bresults['u_email'];
$u_password=$bresults['u_password'];
$u_address=$bresults['u_address'];
$u_district=$bresults['u_district'];
$u_iname=$bresults['u_iname'];
$u_iaddress=$bresults['u_iaddress'];
$u_semister=$bresults['u_semister'];
$u_branch=$bresults['u_branch'];
$u_adnum=$bresults['u_adnum'];
$u_from=$bresults['u_from'];
$u_to=$bresults['u_to'];
$u_status=$bresults['status'];
$img=$bresults['img'];
?>
	
<style type="text/css">
@media print
{    
    .no-print, .no-print *
    {
        display: none !important;
    }
}
.no-print{
     	width:100px;
     	height: 30px;
     	background: green;
     	color: #fff;
     }
.back{
     	width: 100px;
        height: 30px;
        background: #b76969;
        margin-left: 10px;
        color: #fff;
     }
     table{
     	    margin-top: 20px;
         font-size:16px;
         border: none;
     }
</style>

	</head>
	<body>
		<div style="height:80%">




	<!-- 		<table><tr>

				<td>
			<p style="font-size: 10px;font-weight: 600">SMART BUS PASS</td></tr>
<tr>
					<button onclick="window.print();" class='no-print'>Print</button>
                    <button onclick="location.href='https://mobistyle.in/sales/mobi/service.php'" class='no-print back'>Back</button>
                     
				</tr>
			</table> -->
			
	<h1>SMART BUS PASS</h1>
		<table>
<thead>
	<tr>


		
	</tr>
</thead>

<tbody>
<!-- <img src='../htdocs/busspass/uploads/<?php echo $bresults["img"];?>'> -->
<tr>
		<td>Name:<span><?php echo $u_name;?></span></td>
		<td><?php echo"<img  style='width:70px;height:75px;' src='../busspass/uploads/".$bresults['img']."'>"?></td>
	</tr>
<tr>
		<td>ID:<span><?php echo $pid;?></span></td>
</tr>

<tr>
	<td>Address: <span><?php echo $u_address;?></span></td>
</tr>

<tr>
	<td>From: <span><?php echo $u_from;?></span> </td>
	<td>To : <span><?php echo $u_to;?></span></td>
</tr>

<tr>
	<td>
	From:<p id="date"></p></td>
    <td>To:<p id="date1"></p></td>
</tr>






</tbody>

			
		</table>
<script type="text/javascript">
        n =  new Date();
        y = n.getFullYear() ;
        m = n.getMonth() + 1;
		d = n.getDate();
		document.getElementById("date").innerHTML = d + "/" + m + "/" + y;
</script>

<script type="text/javascript">
        n =  new Date();
        y = n.getFullYear()+1 ;
        m = n.getMonth() + 1;
		d = n.getDate();
		document.getElementById("date1").innerHTML = d + "/" + m + "/" + y;
</script>





		
	</body>
</html>