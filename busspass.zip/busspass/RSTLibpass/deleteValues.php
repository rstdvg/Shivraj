<?php

session_start();

require_once 'config.php';

// delete values for brand enteries
if(isset($_GET['delbrand'])) {

  $cid = 'b_id';
  $id = $_GET['delbrand'];
  $table = 'brand';

  if ($optics->deleteValue($table, $cid, $id)) {
    header("location: ../brands.php");
  }
}

// delete values for lens enteries
if(isset($_GET['dellens'])) {

  $cid = 'l_id';
  $id = $_GET['dellens'];
  $table = 'lens';

  if ($optics->deleteValue($table, $cid, $id)) {
    header("location: ../lenses.php");
  }
}

// delete values for frames enteries
if(isset($_GET['delframes'])) {

  $cid = 'f_id';
  $id = $_GET['delframes'];
  $table = 'frames';

  if ($optics->deleteValue($table, $cid, $id)) {
    header("location: ../frames.php");
  }
}

// delete values for sunglasses enteries
if(isset($_GET['delsun'])) {

  $cid = 'su_id';
  $id = $_GET['delsun'];
  $table = 'sunglasses';

  if ($optics->deleteValue($table, $cid, $id)) {
    header("location: ../sunglasses.php");
  }
}

// delete values for clens enteries
if(isset($_GET['delclens'])) {

  $cid = 'cl_id';
  $id = $_GET['delclens'];
  $table = 'contactlens';

  if ($optics->deleteValue($table, $cid, $id)) {
    header("location: ../contactlense_view.php");
  }
}

// delete values for specs enteries
if(isset($_GET['delspecs'])) {

  $cid = 'sp_id';
  $id = $_GET['delspecs'];
  $table = 'spectacles';

  if ($optics->deleteValue($table, $cid, $id)) {
    header("location: ../spectacles_view.php");
  }
}

// delete values for enquire enteries
if(isset($_GET['delEnq'])) {

  $cid = 'e_id';
  $id = $_GET['delEnq'];
  $table = 'enquires';

  if ($optics->deleteValue($table, $cid, $id)) {
    header("location: ../enquires_view.php");
  }
}

// delete values for brand order enteries
if(isset($_GET['delbo'])) {

  $cid = 'bo_id';
  $id = $_GET['delbo'];
  $table = 'order_entry_brands';

  if ($optics->deleteValue($table, $cid, $id)) {
    header("location: ../brand_stock.php");
  }
}

// delete values for lens order enteries
if(isset($_GET['dellensorder'])) {

  $cid = 'lo_id';
  $id = $_GET['dellensorder'];
  $table = 'order_entry_lens';

  if ($optics->deleteValue($table, $cid, $id)) {
    header("location: ../lense_stock.php");
  }
}

// delete values for frames order enteries
if(isset($_GET['delframeorder'])) {

  $cid = 'fo_id';
  $id = $_GET['delframeorder'];
  $table = 'order_entry_frames';

  if ($optics->deleteValue($table, $cid, $id)) {
    header("location: ../frame_stock.php");
  }
}
?>