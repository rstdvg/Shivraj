<?php

class rstClass {
	private $db;

  function __construct($db_con){
    $this->db = $db_con;
  }
// user regisatration
  public function insert_register($u_name,$u_number,$u_email,$u_password,$u_address,$u_district,$u_iname,$u_iaddress,$u_semister,$u_branch,$u_adnum,$u_from,$u_to,$u_status,$file,$date) {
    try {
      $stmt = $this->db->prepare("INSERT INTO register(u_name,u_number,u_email,u_password,u_address,u_district,u_iname,u_iaddress,u_semister,u_branch,u_adnum,u_from,u_to,status,img,date) VALUES 

        (:u_name,:u_number,:u_email,:u_password,:u_address,:u_district,:u_iname,:u_iaddress,:u_semister,:u_branch,:u_adnum,:u_from,:u_to,:u_status,:img,:date)");

       $stmt->bindParam(':u_name',$u_name);
      $stmt->bindParam(':u_number',$u_number);
      $stmt->bindParam(':u_email',$u_email);
      $stmt->bindParam(':u_password',$u_password);
      $stmt->bindParam(':u_address',$u_address);
      $stmt->bindParam(':u_district',$u_district);
      $stmt->bindParam(':u_iname',$u_iname);
      $stmt->bindParam(':u_iaddress',$u_iaddress);
      $stmt->bindParam(':u_semister',$u_semister);
      $stmt->bindParam(':u_branch',$u_branch);
      $stmt->bindParam(':u_adnum',$u_adnum);
      $stmt->bindParam(':u_from',$u_from);
      $stmt->bindParam(':u_to',$u_to);
      $stmt->bindParam(':u_status',$u_status);
      $stmt->bindParam(':img',$file);
      $stmt->bindParam(':date',$date);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

//login insert
   public function insert_login($u_email,$u_password,$role) {
    try {
      $stmt = $this->db->prepare("INSERT INTO login(email,password,role) VALUES 

        (:u_email,:u_password,:u_role)");

       $stmt->bindParam(':u_email',$u_email);
      $stmt->bindParam(':u_password',$u_password);
      $stmt->bindParam(':u_role',$role);
      $stmt->execute();
      return $stmt;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }

//login fetch
   public function fetch_login($table,$email,$password) {
    try {
      $stmt = $this->db->prepare("SELECT * FROM $table WHERE email=:u_email AND password=:u_password");
     $stmt->bindParam(':u_email',$email);
     $stmt->bindParam(':u_password',$password);
     $stmt->execute();
     $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    } catch (PDOException $e){
      echo $e->getMessage();
    }
  }


public function fetch_applied($table) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }

public function fetch_register($table,$id)
{
  try{
      $stmt = $this->db->prepare("SELECT * FROM $table where id=:id");
      $stmt->bindParam(':id',$id);
      $stmt->execute();
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
}


public function fetch_status($table,$status)
{
  try{
      $stmt = $this->db->prepare("SELECT * FROM $table where id=:sid");
      $stmt->bindParam(':sid',$status);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
}



public function update_status($table,$status,$status2)
{
  try{
      $stmt = $this->db->prepare("UPDATE $table SET status=:status2 WHERE id=:status");
      $stmt->bindParam(':status2',$status2);
      $stmt->bindParam(':status',$status);
      $stmt->execute();
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
}



public function fetch_rejected($table,$status) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table WHERE status=$status");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }

public function fetch_approved($table,$status) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table WHERE status=$status");
      $stmt->execute();
      $result = $stmt->fetchAll();
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }


  public function buspassprint($table,$pid) {
    try{
      $stmt = $this->db->prepare("SELECT * FROM $table WHERE id=$pid");
      $stmt->execute();
     
      $result = $stmt->fetch(PDO::FETCH_ASSOC);
      return $result;
    } 
    catch (PDOException $e){
      echo $e->getMessage();
    }
  }


 public function single_userinfo($table,$name){
  try{
    $stmt = $this->db->prepare("SELECT * FROM $table WHERE u_email=:email");
    $stmt->bindParam(':email',$name);
    $stmt->execute();
   
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    return $result;
  } 
  catch (PDOException $e){
    echo $e->getMessage();
  }
 }











}

?>
